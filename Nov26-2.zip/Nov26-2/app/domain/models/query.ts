export class Query{  minRating: any;

    budget?:number;
    origin?:string;
    startDate?:string;
    endDate?:string;
    locationCategory?:string;
    minDistance?:number;
    maxDistance?:number;
}