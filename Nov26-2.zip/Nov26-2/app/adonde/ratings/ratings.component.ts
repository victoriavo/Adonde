import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpClientModule, HttpResponse } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { Rating, ratingService } from '../../domain/index';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'ratings', 
  templateUrl: './ratings.component.html',
  styleUrls: ['./ratings.component.css']
})



export class RatingsComponent {
  public ratingValues = ['1 star','2 stars','3 stars','4 stars','5 stars'];
  public newLocationRating = new Rating;
  location_id : number;
  public ratingCount : number;
  public ratingAverage : number;
  public loggedIn : boolean;

  @Input()
  public locationRatings : Rating[] = [];

  constructor(
    public http: HttpClient,
    public router: Router,
    route: ActivatedRoute
  ) {
    this.location_id = route.snapshot.params['location_id'];
    this.getAllRatings();
  }  

  public ngOnInit() {

    if(localStorage.getItem('session_id') !== null && localStorage.getItem('session_id') != '0'){
      console.log(localStorage.getItem('session_id'));
      this.http.get('http://ec2-18-216-113-131.us-east-2.compute.amazonaws.com/session/' + localStorage.getItem('session_id')
      ).subscribe(data => { console.log(data)
          if(data['valid'] == 1){
              this.loggedIn = true;
          }else{
              this.loggedIn = false;
              localStorage.removeItem('session_id');
          }
      });
    }else{
      this.loggedIn = false;
      console.log('not logged in');
    }
  
    
  }
  

 private getAllRatings(){
  this.http.get<Rating[]>('http://ec2-18-216-113-131.us-east-2.compute.amazonaws.com/location_ratings/' + this.location_id)
    .subscribe(data => {
    console.log(data);

    this.ratingAverage = data['average'];
    this.ratingCount = data['numRatings'];

  });

 }
	


  private addLocationRating() {
    this.newLocationRating.date = new Date();
    this.locationRatings.push(this.newLocationRating);
    this.newLocationRating = new Rating;

    console.log(this.newLocationRating.rating);
    const body = {"location_id": this.location_id, "rating": this.newLocationRating.rating};
    this.http.put('http://ec2-18-216-113-131.us-east-2.compute.amazonaws.com/rate', body
    ).subscribe(data => {
      console.log(data); 
      //console.log(this.newLocationRating.rating)
    });
    
    this.newLocationRating = new Rating;
  }

  public goToLogin(){
    this.router.navigateByUrl('/login');
  }
}

