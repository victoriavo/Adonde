import { Time } from "@angular/common";

export class Flight{
    origin: string;
    destination: string;
    cost: number;
    depart_date: Date;
    airlines: string;
    depart_port: string;
    arrival_port: string;
    air_time: Time;
    distance: number;
    link: string;
}