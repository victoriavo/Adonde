export class Locationrating {
    userName?: string;
    rating?: number;
    date?: Date;
    comment?: string;
}

//location id as an integer
//rating number as an integer up to 
