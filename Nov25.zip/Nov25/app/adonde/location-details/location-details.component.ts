import { Component, OnInit, Input } from '@angular/core';
import { Location, Rating} from '../../domain';
import { HttpClient, HttpClientModule, HttpResponse } from '@angular/common/http';
import {ActivatedRoute} from '@angular/router';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'location-details',
  templateUrl: './location-details.component.html',
  styleUrls: ['./location-details.component.css']
})
export class LocationDetailsComponent {
  trustedUrl: SafeResourceUrl;
  dangerousUrl: any;
  location: any;
  public results: string;
  location_id : number;
  public ratings: Rating[] = [];
  mapUrl : string;
  
 
  

  constructor(
    public http: HttpClient,
    route: ActivatedRoute,
    public sanitizer: DomSanitizer
  ){
    this.location = Location;
    this.location_id = route.snapshot.params['location_id'];
    this.http.get<Location>('http://ec2-18-216-113-131.us-east-2.compute.amazonaws.com/locations/'+this.location_id).subscribe(data => {
      // Read the result field from the JSON response.
      //this.results = JSON.stringify(data);
      //this.location= data[0];
      this.location = 
      { 
        location_id: this.location_id,
        city: "Los Angeles",
        country: "America",
        description: "pretty cool",
        imagePath: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Space_Needle002.jpg/1200px-Space_Needle002.jpg",
        rating: 52.84,
        ratings: [],
        mapPath: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d317715.7118979552!2d-0.38177932402906867!3d51.52873520163295!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47d8a00baf21de75%3A0x52963a5addd52a99!2sLondon%2C+UK!5e0!3m2!1sen!2sus!4v1511409328497"
      }
      console.log(this.location);
      this.dangerousUrl = this.location.mapPath;
      this.trustedUrl = sanitizer.bypassSecurityTrustResourceUrl(this.dangerousUrl);
      console.log(this.dangerousUrl);
      console.log(this.trustedUrl);
      
    });
  }

  public save(){
    //think this would be a post to the db
    //if (this.location_id) {
    //  this.location.ratings.update(this.location_id, this.location).subscribe();
    //} 
    
  }  

 

}