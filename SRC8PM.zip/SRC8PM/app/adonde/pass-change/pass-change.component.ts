import { Component, OnInit, Input } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import {User} from '../../domain';


@Component({
    selector: 'pass-change',
    templateUrl: './pass-change.component.html',
    styleUrls: ['./pass-change.component.css']
})

export class PassChangeComponent {
    public newUser = new User();

    constructor(
        public http: HttpClient
    ) {}
    
    public change(){
        const body = {email: 'spenccheng@gmail.com', password: this.newUser.password};
        this.http.put('http://ec2-18-216-113-131.us-east-2.compute.amazonaws.com/update', body).subscribe();
        alert('Success');
    }

}