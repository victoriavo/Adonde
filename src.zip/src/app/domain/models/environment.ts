export class Environment{
    environment_id: number;
    environment: string;
}