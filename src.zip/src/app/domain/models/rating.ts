export class Rating{
    userName?: string;
    rating?: number;
    date?: Date;
}