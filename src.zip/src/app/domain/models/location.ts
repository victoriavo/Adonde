export class Location{
    name: string;
    description: string;
    imageName: string;
    category: string;
}