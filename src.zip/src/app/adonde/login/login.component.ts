import { Component, OnInit, Input} from '@angular/core';
import { HttpClient, HttpClientModule, HttpResponse } from '@angular/common/http';
import {User} from '../../domain';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent{
    private user = new User();
    private login(){
        
    }
    constructor(private http: HttpClient){
      this.http.get('http://ec2-18-216-113-131.us-east-2.compute.amazonaws.com/accounts').subscribe(data => {
        // Read the result field from the JSON response.
        console.log(data);
      });
    }

    
}
