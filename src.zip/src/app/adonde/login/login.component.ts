import { Component, OnInit, Input} from '@angular/core';
import { HttpClient, HttpClientModule, HttpResponse } from '@angular/common/http';
import {User} from '../../domain';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent{
    private user = new User();
    private login(){
        
    }

}
