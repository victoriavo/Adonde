import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'bg-animation',
  templateUrl: './bg-animation.component.html',
  styleUrls: ['./bg-animation.component.css']
})
export class bgAnimationComponent {

}